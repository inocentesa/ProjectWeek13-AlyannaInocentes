#!/bin/bash
awk '{print $1,$2,$5,$6}' 0310_Dealer_schedule 0312_Dealer_schedule 0315_Dealer_schedule > 1.txt
grep "05:00:00 AM\|08:00:00 AM\|02:00:00 PM\|11:00:00PM" 1 > Notes_Dealer_Analysis
wc -l Notes_Dealer_Analysis >> Notes_Dealer_Analysis
rm 1.txt
cat Notes_Dealer_Analysis
