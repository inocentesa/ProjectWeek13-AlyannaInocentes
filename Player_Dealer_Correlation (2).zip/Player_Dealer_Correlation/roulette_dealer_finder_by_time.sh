#!/bin/bash
awk '{print $1,$2,$5,$6}' $1_Dealer_schedule > 1 | grep "$2" 1 > Notes_Dealer_Analysis | rm 1
cat Notes_Dealer_Analysis
